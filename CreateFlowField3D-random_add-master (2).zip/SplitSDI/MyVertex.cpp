#include "stdafx.h"
#include "MyVertex.h"


CMyVertex::CMyVertex()
{
}


CMyVertex::~CMyVertex()
{
}
